from mesa.discrete_space import CellAgent, FixedAgent
from collections import deque

class RandomAgent(CellAgent):
    """Roomba que evita choques, comparte información de estaciones y gestiona batería"""
    def __init__(self, model, cell):
        super().__init__(model)
        self.model = model
        self.cell = cell
        self.cell.agents.append(self)
        self.battery = 100
        self.movements = 0
        self.path = []
        self.state = "search_dirty"
        self.charging_station = cell  # estación inicial

        # Registrar estación inicial en la lista global
        self.model.known_stations.add(cell)

    def recharge(self):
        """Recarga 5% si hay estación de carga en la celda"""
        if any(isinstance(a, ChargingStation) for a in self.cell.agents):
            self.battery = min(100, self.battery + 5)
            # Registrar esta estación en la lista global
            self.model.known_stations.add(self.cell)

    def needs_charge(self):
        """Verifica si necesita recargar"""
        distance_to_station = self.bfs_distance_to_nearest_station()
        return self.battery < distance_to_station + 1  # +1 porque cada paso gasta 1%

    def bfs_distance_to_nearest_station(self):
        """Distancia mínima a cualquier estación conocida"""
        queue = deque([(self.cell, 0)])
        visited = {self.cell}
        while queue:
            current, dist = queue.popleft()
            if current in self.model.known_stations:
                return dist
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents) and
                          all(not isinstance(a, RandomAgent) for a in c.agents)
            )
            for n in neighbors:
                if n not in visited:
                    visited.add(n)
                    queue.append((n, dist + 1))
        return float('inf')

    def find_path_to_station(self):
        """BFS a la estación conocida más cercana evitando otros Roombas"""
        queue = deque([(self.cell, [self.cell])])
        visited = {self.cell}
        while queue:
            current, path = queue.popleft()
            if current in self.model.known_stations:
                return path[1:]  # Excluir celda actual
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents) and
                          all(not isinstance(a, RandomAgent) for a in c.agents)
            )
            for n in neighbors:
                if n not in visited:
                    visited.add(n)
                    queue.append((n, path + [n]))
        return []

    def find_nearest_dirty_bfs(self):
        """Encuentra celda sucia más cercana usando BFS evitando Roombas"""
        queue = deque([(self.cell, [self.cell])])
        visited = {self.cell}
        while queue:
            current, path = queue.popleft()
            if any(isinstance(a, DirtyCell) for a in current.agents):
                return path[1:]
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents) and
                          all(not isinstance(a, RandomAgent) for a in c.agents)
            )
            for n in neighbors:
                if n not in visited:
                    visited.add(n)
                    queue.append((n, path + [n]))
        return []

    def move_along_path(self):
        if self.path:
            next_cell = self.path[0]
            if not any(isinstance(a, RandomAgent) for a in next_cell.agents):
                self.cell.agents.remove(self)
                self.cell = next_cell
                self.cell.agents.append(self)
                self.path.pop(0)
                self.movements += 1
                self.battery = max(0, self.battery - 1)  # Limitar a 0

    def clean(self):
        dirt = next((a for a in self.cell.agents if isinstance(a, DirtyCell)), None)
        if dirt:
            dirt.remove()
            self.battery = max(0, self.battery - 1)
            self.path = []

    def step(self):
        # Recargar si hay estación
        self.recharge()

        # Estado: ir a cargar si batería baja
        if self.needs_charge():
            self.state = "go_charge"
            if not self.path:
                self.path = self.find_path_to_station()
        else:
            self.state = "search_dirty"
            if not self.path:
                self.path = self.find_nearest_dirty_bfs()

        # Moverse
        self.move_along_path()

        # Limpiar si hay suciedad
        self.clean()

class DirtyCell(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass

class ObstacleAgent(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass

class ChargingStation(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass