from random_agents.agent import RandomAgent, ObstacleAgent, DirtyCell, ChargingStation
from random_agents.model import RandomModel

from mesa.visualization import (
    Slider,
    SolaraViz,
    make_space_component,
    make_plot_component,
)

from mesa.visualization.components import AgentPortrayalStyle


def random_portrayal(agent):
    if agent is None:
        return

    portrayal = AgentPortrayalStyle(size=50, marker="o")

    if isinstance(agent, RandomAgent):
        portrayal.color = "blue"
    elif isinstance(agent, ObstacleAgent):
        portrayal.color = "gray"
        portrayal.marker = "s"
        portrayal.size = 100
    elif isinstance(agent, DirtyCell):
        portrayal.color = "black"
    elif isinstance(agent, ChargingStation):
        portrayal.color = "green"
        portrayal.marker = "s"
        portrayal.size = 100

    return portrayal


def post_process(ax):
    ax.set_aspect("equal")


model_params = {
    "seed": {"type": "InputText", "value": 42, "label": "Random Seed"},
    "width": Slider("Grid width", 28, 1, 50),
    "height": Slider("Grid height", 28, 1, 50),
}

model = RandomModel(
    width=model_params["width"].value,
    height=model_params["height"].value,
    seed=model_params["seed"]["value"]
)

space_component = make_space_component(
    random_portrayal,
    draw_grid=False,
    post_process=post_process
)

# ----------- GRÁFICAS -----------

# Gráfica 1: Número de DirtyCells
dirty_count_plot = make_plot_component(
    {"DirtyCells": "black"}
)

# Gráfica 2: Batería de la Roomba
battery_plot = make_plot_component(
    {"RoombaBattery": "blue"}
)

# Gráfica 3: Número de Steps
steps_plot = make_plot_component(
    {"Steps": "green"}
)

page = SolaraViz(
    model,
    components=[space_component, dirty_count_plot, battery_plot, steps_plot],
    model_params=model_params,
    name="Roomba Cleaning Simulation",
)