from mesa import Model
from mesa.datacollection import DataCollector
from mesa.discrete_space import OrthogonalMooreGrid
from .agent import RandomAgent, ObstacleAgent, DirtyCell, ChargingStation


class RandomModel(Model):
    def __init__(self, width=8, height=8, dirty_percent=0.2, seed=42, obstacle_percent=0.1):
        super().__init__(seed=seed)

        self.width = width
        self.height = height
        self.dirty_percent = dirty_percent
        self.obstacle_percent = obstacle_percent
        self.steps_count = 0  # Contador de steps

        # Pasar el random generator para evitar warning
        self.grid = OrthogonalMooreGrid(
            [self.width, self.height], 
            torus=False,
            random=self.random
        )

        # ---- Borde de obstáculos ----
        border = [
            (x, y)
            for y in range(self.height)
            for x in range(self.width)
            if y == 0 or y == self.height - 1 or x == 0 or x == self.width - 1
        ]

        # Recorremos SIEMPRE grid.all_cells (no grid directamente)
        for cell in self.grid.all_cells:
            if cell.coordinate in border:
                ObstacleAgent(self, cell)

        # ---- Estación de carga ----
        charging_cell = self.grid[1, 1]
        ChargingStation(self, charging_cell)

        # ---- Agente principal ----
        self.roomba = RandomAgent(self, charging_cell)

        # ---- Celdas vacías internas ----
        available_cells = [
            cell
            for cell in self.grid.empties
            if cell.coordinate != (1, 1) and cell.coordinate not in border
        ]

        # ---- DirtyCells ----
        num_dirty = int(len(available_cells) * self.dirty_percent)
        dirty_cells = self.random.sample(available_cells, k=num_dirty)

        DirtyCell.create_agents(self, num_dirty, dirty_cells)

        self.initial_dirty = num_dirty

        # ---- Remover dirtycells de los disponibles ----
        available_cells = [c for c in available_cells if c not in dirty_cells]

        # ---- Obstáculos internos ----
        num_obstacles = int(len(available_cells) * self.obstacle_percent)
        obstacle_cells = self.random.sample(available_cells, k=num_obstacles)

        ObstacleAgent.create_agents(self, num_obstacles, obstacle_cells)

        # ---- DATA COLLECTOR para las gráficas ----
        self.datacollector = DataCollector({
            "DirtyCells": lambda m: len(m.agents_by_type[DirtyCell]),
            "RoombaBattery": lambda m: m.roomba.battery,
            "Steps": lambda m: m.steps_count,
        })

        self.running = True
        self.datacollector.collect(self)

    def step(self):
        self.agents.shuffle_do("step")
        self.steps_count += 1
        self.datacollector.collect(self)