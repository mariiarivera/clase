from mesa.discrete_space import CellAgent, FixedAgent
from collections import deque


class RandomAgent(CellAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        self.battery = 100
        self.movements = 0
        self.path = []               # Camino a seguir
        self.charging_station = None # Referencia a la estación de carga
        self.state = "search_dirty"  # Estado inicial
        self.find_charging_station()

    def find_charging_station(self):
        for cell in self.model.grid.all_cells:
            if any(isinstance(a, ChargingStation) for a in cell.agents):
                self.charging_station = cell
                return

    def recharge(self):
        if any(isinstance(a, ChargingStation) for a in self.cell.agents):
            self.battery = min(100, self.battery + 25)
            self.state = "charging"

    def needs_charge(self):
        if not self.charging_station:
            return self.battery < 30
        
        distance_to_station = self.bfs_distance(self.cell, self.charging_station)
        return self.battery < (distance_to_station + 10)

    def bfs_distance(self, start, goal):
        if start == goal:
            return 0
        
        queue = deque([(start, 0)])
        visited = {start}
        
        while queue:
            current, distance = queue.popleft()
            
            if current == goal:
                return distance
            
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents)
            )
            
            for neighbor in neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, distance + 1))
        
        return float('inf')

    def find_nearest_dirty_bfs(self):
        queue = deque([(self.cell, [self.cell])])
        visited = {self.cell}
        
        while queue:
            current, path = queue.popleft()
            
            if any(isinstance(a, DirtyCell) for a in current.agents):
                return path[1:]
            
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents)
            )
            
            for neighbor in neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return []

    def find_path_to_charging_station(self):
        if not self.charging_station:
            return []
        
        queue = deque([(self.cell, [self.cell])])
        visited = {self.cell}
        
        while queue:
            current, path = queue.popleft()
            
            if current == self.charging_station:
                return path[1:]
            
            neighbors = current.neighborhood.select(
                lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents)
            )
            
            for neighbor in neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return []

    def check_nearby_dirty(self):
        neighbors = self.cell.neighborhood.select(
            lambda c: all(not isinstance(a, ObstacleAgent) for a in c.agents)
        )
        
        for neighbor in neighbors:
            if any(isinstance(a, DirtyCell) for a in neighbor.agents):
                return neighbor
        return None

    def move_along_path(self):
        if self.path:
            next_cell = self.path.pop(0)
            self.cell = next_cell
            self.movements += 1
            self.battery -= 1
            return True
        return False

    def clean(self):
        dirt = next((a for a in self.cell.agents if isinstance(a, DirtyCell)), None)
        if dirt:
            dirt.remove()
            self.battery -= 1
            self.path = []
            self.state = "search_dirty"
            return True
        return False

    def step(self):

        # ============================================================
        #  🔋 SISTEMA DE CARGA — CORRECTAMENTE IMPLEMENTADO
        # ============================================================

        # Si está en estación de carga
        if any(isinstance(a, ChargingStation) for a in self.cell.agents):

            # Si todavía no llega a 100 → cargar y detener todo lo demás
            if self.battery < 100:
                self.state = "charging"
                self.recharge()
                return  # ← IMPORTANTE para evitar que busque suciedad mientras carga

            # Si ya está al 100 → volver a buscar suciedad
            else:
                self.state = "search_dirty"
                # No hacemos return — dejamos que siga su lógica normal

        # Si la batería llegó a 0 → muere
        if self.battery <= 0:
            self.state = "dead"
            return

        # Suciedad cercana
        nearby_dirty = self.check_nearby_dirty()
        if nearby_dirty and not self.needs_charge():
            self.state = "search_dirty"
            self.path = [nearby_dirty]

        # Necesita carga
        if self.needs_charge() and not any(isinstance(a, ChargingStation) for a in self.cell.agents):
            if not self.path:
                self.path = self.find_path_to_charging_station()
            self.state = "go_charge"

        # Buscar suciedad
        if not self.path and not self.needs_charge():
            self.state = "search_dirty"
            self.path = self.find_nearest_dirty_bfs()

        # Moverse
        self.move_along_path()

        # Limpiar
        self.clean()


class DirtyCell(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass


class ObstacleAgent(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass


class ChargingStation(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        cell.agents.append(self)
    def step(self):
        pass
